export interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: string;
  image: string;
  isSoldOut: boolean;
}

export const thaiDishes: MenuItem[] = [
  {
    id: 1,
    name: "冬阴功汤",
    description: "传统泰国酸辣虾汤，配以香茅、柠檬叶和蘑菇",
    price: "¥68",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Thai%20Tom%20Yum%20Soup%20spicy%20sour%20shrimp%20herbs&sign=7bb2c53b66110f3febf2066d2e8d76e2",
    isSoldOut: false
  },
  {
    id: 2,
    name: "泰式青咖喱鸡",
    description: "香浓的青咖喱配以鸡肉、茄子和泰国罗勒",
    price: "¥88",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Thai%20Green%20Curry%20Chicken%20rice%20herbs&sign=fb33d5e1666d8b0f575081efb21e94f9",
    isSoldOut: false
  },
  {
    id: 3,
    name: "泰式菠萝炒饭",
    description: "香喷喷的炒饭配以新鲜菠萝、虾仁和腰果",
    price: "¥78",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Thai%20Pineapple%20Fried%20Rice%20shrimp%20cashew%20nuts&sign=d32b3622b5cafb8c0397df062346e8c1",
    isSoldOut: false
  }
];

export const burmeseDishes: MenuItem[] = [
  {
    id: 10,
    name: "缅甸鱼汤米线",
    description: "鲜美的鱼汤配以米线、鱼肉和香草",
    price: "¥66",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Burmese%20Fish%20Soup%20Noodles%20herbs%20fresh&sign=5159819a4ba61e92bb4c508e6ae301fc",
    isSoldOut: false
  },
  {
    id: 11,
    name: "缅甸茶叶沙拉",
    description: "传统缅甸风味沙拉，配以茶叶、坚果和豆类",
    price: "¥58",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Burmese%20Tea%20Leaf%20Salad%20nuts%20beans&sign=6c6986946ff4ccc97cffb7f44b7a9a66",
    isSoldOut: false
  },
  {
    id: 12,
    name: "缅甸咖喱面",
    description: "浓郁的咖喱汤底配以手工面条和牛肉",
    price: "¥72",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Burmese%20Curry%20Noodles%20beef%20spices&sign=d59c152ae835fef7e3bef20ed14e02a1",
    isSoldOut: false
  }
];

export const taiwaneseDishes: MenuItem[] = [
  {
    id: 20,
    name: "台湾卤肉饭",
    description: "香喷喷的白米饭配以慢炖五花肉和卤汁",
    price: "¥58",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Taiwanese%20Braised%20Pork%20Rice%20glaze%20green%20onion&sign=0b66ec5da5f9196517240c08439ec489",
    isSoldOut: false
  },
  {
    id: 21,
    name: "蚵仔煎",
    description: "传统台湾小吃，配以新鲜蚵仔、鸡蛋和蔬菜",
    price: "¥62",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Taiwanese%20Oyster%20Omelette%20seafood%20vegetables&sign=069ba4601a3917784ca473f453efed07",
    isSoldOut: false
  },
  {
    id: 22,
    name: "珍珠奶茶",
    description: "经典台湾饮品，配以黑糖珍珠和鲜奶",
    price: "¥32",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Taiwanese%20Bubble%20Tea%20milk%20tapioca%20pearls&sign=737712eff468ee038e56b1e6fa132dcc",
    isSoldOut: false
  }
];

// 从本地存储获取菜单数据，如果没有则使用初始数据
const getMenuData = () => {
  const savedMenu = localStorage.getItem('restaurantMenu');
  
  if (savedMenu) {
    try {
      const parsedMenu = JSON.parse(savedMenu);
      return {
        thai: parsedMenu.thai || thaiDishes,
        burmese: parsedMenu.burmese || burmeseDishes,
        taiwanese: parsedMenu.taiwanese || taiwaneseDishes
      };
    } catch (error) {
      console.error('Failed to parse menu data from localStorage', error);
    }
  }
  
  // 如果本地存储中没有数据或解析失败，返回初始数据
  return {
    thai: thaiDishes,
    burmese: burmeseDishes,
    taiwanese: taiwaneseDishes
  };
};

// 导出菜单数据获取函数
export { getMenuData };