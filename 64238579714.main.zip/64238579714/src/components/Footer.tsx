import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 flex items-center">
              <i className="fa-solid fa-utensils mr-2"></i>
              东南亚风情
            </h3>
            <p className="text-gray-300 mb-4">
              品尝地道的泰国、缅甸和台湾美食，体验东南亚的独特风味。
            </p>
             <div className="flex space-x-4">
               <a href="#" className="text-gray-300 hover:text-amber-400 transition-colors cursor-not-allowed" title="部署后可配置">
                 <i className="fa-brands fa-facebook"></i>
               </a>
               <a href="#" className="text-gray-300 hover:text-amber-400 transition-colors cursor-not-allowed" title="部署后可配置">
                 <i className="fa-brands fa-instagram"></i>
               </a>
               <a href="#" className="text-gray-300 hover:text-amber-400 transition-colors cursor-not-allowed" title="部署后可配置">
                 <i className="fa-brands fa-weixin"></i>
               </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">快速链接</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-gray-300 hover:text-amber-400 transition-colors">首页</Link></li>
              <li><Link to="/menu" className="text-gray-300 hover:text-amber-400 transition-colors">菜单</Link></li>
              <li><Link to="/contact" className="text-gray-300 hover:text-amber-400 transition-colors">联系方式</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">联系我们</h4>
            <ul className="space-y-2 text-gray-300">
              <li className="flex items-start">
                <i className="fa-solid fa-map-marker mt-1 mr-3 text-amber-400"></i>
                <span>北京市朝阳区建国路88号</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-phone mr-3 text-amber-400"></i>
                <span>0905862449</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-envelope mr-3 text-amber-400"></i>
                <span>decun172@gmail.com</span>
              </li>
            </ul>
          </div>
        </div>
        
         <div className="border-t border-gray-700 mt-8 pt-8">
           <div className="text-center text-gray-400 mb-4">
             <p>管理员请 <a href="/login" className="text-amber-400 hover:underline">登录</a> 管理后台</p>
           </div>
           <div className="text-center text-gray-400">
             <p>&copy; {new Date().getFullYear()} 东南亚风情餐厅. 保留所有权利.</p>
           </div>
         </div>
      </div>
    </footer>
  );
}