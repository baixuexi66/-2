import { cn } from '@/lib/utils';

interface DishCardProps {
  image: string;
  name: string;
  description: string;
  price: string;
  className?: string;
  isSoldOut: boolean;
}

export default function DishCard({ 
  image, 
  name, 
  description, 
  price, 
  className 
}: DishCardProps) {
  return (
    <div className={cn(
      "bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 transform hover:-translate-y-1",
      className
    )}>

      <div className="p-5">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-lg font-bold text-gray-800">{name}</h3>
          <span className="text-amber-600 font-semibold">{price}</span>
        </div>
        <p className="text-gray-600 text-sm line-clamp-2">{description}</p>
      </div>
    </div>
  );
}