import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

// 定义消息类型
interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export default function AIChatbot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  
  // 客服回复内容库
  const responses = {
    location: "我们的餐厅位于北京市朝阳区建国路88号，交通便利，地铁1号线和14号线均可到达。",
    address: "我们的详细地址是：北京市朝阳区建国路88号东南亚风情餐厅。",
    hours: "我们的营业时间：周一至周五: 11:00 - 14:30, 17:00 - 22:00；周六至周日: 11:00 - 22:30。",
    
    // 菜谱相关回复
    menuThai: "我们的泰国料理包括冬阴功汤、泰式青咖喱鸡和泰式菠萝炒饭等经典菜品。",
    menuBurmese: "缅甸料理推荐：鱼汤米线、茶叶沙拉和缅甸咖喱面。",
    menuTaiwanese: "台湾料理特色：卤肉饭、蚵仔煎和珍珠奶茶。",
    
    // 食材相关回复
    ingredientsTomYum: "冬阴功汤的主要食材包括：鲜虾、香茅、柠檬叶、青柠汁、鱼露和泰国辣椒。",
    ingredientsGreenCurry: "泰式青咖喱鸡的主要食材包括：鸡肉、青咖喱酱、椰奶、茄子和泰国罗勒。",
    ingredientsBraisedPork: "台湾卤肉饭的主要食材包括：五花肉、米饭、葱、姜、蒜和特制卤汁。",
    
    default: "感谢您的咨询！我们可以为您提供餐厅地址、营业时间、菜品介绍和食材信息。请问有什么可以帮助您的？"
  };
  
  // 处理发送消息
  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    
    // 添加用户消息
    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    
    // 生成机器人回复
    generateBotResponse(inputText);
  };
  
  // 生成机器人回复
  const generateBotResponse = (userInput: string) => {
    const lowerInput = userInput.toLowerCase();
    let responseKey: keyof typeof responses = 'default';
    
    // 简单的关键词识别
    if (lowerInput.includes('地址') || lowerInput.includes('在哪里') || lowerInput.includes('位置')) {
      responseKey = lowerInput.includes('详细') ? 'address' : 'location';
    } else if (lowerInput.includes('时间') || lowerInput.includes('营业') || lowerInput.includes('几点')) {
      responseKey = 'hours';
    } else if (lowerInput.includes('泰国') || lowerInput.includes('泰式')) {
      responseKey = 'menuThai';
    } else if (lowerInput.includes('缅甸')) {
      responseKey = 'menuBurmese';
    } else if (lowerInput.includes('台湾')) {
      responseKey = 'menuTaiwanese';
    } else if (lowerInput.includes('冬阴功') || lowerInput.includes('tom yum')) {
      responseKey = 'ingredientsTomYum';
    } else if (lowerInput.includes('青咖喱')) {
      responseKey = 'ingredientsGreenCurry';
    } else if (lowerInput.includes('卤肉饭') || lowerInput.includes('braised pork')) {
      responseKey = 'ingredientsBraisedPork';
    }
    
    // 模拟思考时间后回复
    setTimeout(() => {
      const botMessage: ChatMessage = {
        id: `bot-${Date.now()}`,
        text: responses[responseKey],
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    }, 800);
  };
  
  // 处理键盘回车发送消息
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };
  
  // 组件挂载时发送欢迎消息
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      const welcomeMessage: ChatMessage = {
        id: `bot-welcome-${Date.now()}`,
        text: "您好！我是东南亚风情餐厅的AI客服。请问有什么可以帮助您的？",
        sender: 'bot',
        timestamp: new Date()
      };
      
      setMessages([welcomeMessage]);
    }
  }, [isOpen]);
  
  return (
      <div className="fixed bottom-8 right-8 z-50 w-80 transform-gpu translate-y-0">
      {/* 折叠状态 - 仅显示图标按钮 */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="bg-amber-600 hover:bg-amber-700 text-white p-4 rounded-full shadow-lg transition-all transform hover:scale-110"
          aria-label="打开AI客服"
        >
          <i className="fa-solid fa-comments text-xl"></i>
        </button>
      )}
      
      {/* 展开状态 - 显示完整聊天窗口 */}
      {isOpen && (
        <div className="bg-white rounded-xl shadow-2xl overflow-hidden flex flex-col h-[450px] border border-gray-200">
          {/* 聊天窗口头部 */}
          <div className="bg-amber-600 text-white p-4 flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <i className="fa-solid fa-robot text-xl"></i>
              <h3 className="font-semibold">东南亚风情 AI客服</h3>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:text-gray-200 transition-colors"
              aria-label="关闭"
            >
              <i className="fa-solid fa-times"></i>
            </button>
          </div>
          
          {/* 聊天消息区域 */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.map((message) => (
              <div 
                key={message.id} 
                className={cn(
                  "flex max-w-[80%]",
                  message.sender === 'user' ? 'ml-auto justify-end' : 'mr-auto'
                )}
              >
                <div 
                  className={cn(
                    "px-4 py-2 rounded-lg shadow-sm",
                    message.sender === 'user' 
                      ? 'bg-amber-600 text-white rounded-br-none' 
                      : 'bg-white text-gray-800 rounded-bl-none border border-gray-200'
                  )}
                >
                  <p>{message.text}</p>
                </div>
              </div>
            ))}
          </div>
          
          {/* 输入区域 */}
          <div className="p-3 border-t border-gray-200">
            <div className="flex space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="输入您的问题..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              />
              <button
                onClick={handleSendMessage}
                className="bg-amber-600 hover:bg-amber-700 text-white p-2 rounded-full transition-colors"
                aria-label="发送"
              >
                <i className="fa-solid fa-paper-plane"></i>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}