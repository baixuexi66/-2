import DishCard from './DishCard';

interface MenuItem {
  id: number;
  name: string;
  description: string;
  price: string;
  image: string;
}

interface MenuSectionProps {
  title: string;
  description: string;
  items: MenuItem[];
  icon: string;
  color: string;
}

export default function MenuSection({ 
  title, 
  description, 
  items, 
  icon, 
  color 
}: MenuSectionProps) {
  return (
    <section className="py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className={`inline-block p-3 rounded-full ${color} mb-4`}>
            <i className={`fa-solid ${icon} text-white text-2xl`}></i>
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-3">{title}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">{description}</p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {items.map((item) => (
               <DishCard 
                 key={item.id}
                 image={item.image}
                 name={item.name}
                 description={item.description}
                 price={item.price}
                 isSoldOut={item.isSoldOut}
               />
          ))}
        </div>
      </div>
    </section>
  );
}