export default function Hero() {
  return (
    <section className="relative h-[80vh] overflow-hidden">
      {/* 背景图片 */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Southeast%20Asian%20restaurant%20interior%20warm%20lighting%20wooden%20furniture%20traditional%20decorations&sign=d6d63a4b689e14636517b29f4fcc1430" 
          alt="东南亚风情餐厅环境" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      
      {/* 英雄内容 */}
      <div className="relative z-10 h-full flex flex-col justify-center items-center text-center px-4 text-white">
        <h1 className="text-4xl md:text-6xl font-bold mb-4 tracking-tight animate-fade-in">
          东南亚风情
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl animate-fade-in-delay">
          品味泰国、缅甸和台湾的地道美食，感受东南亚的热情与风味
        </p>
        <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-delay-2">
          <a 
            href="/menu" 
            className="bg-amber-600 hover:bg-amber-700 text-white font-medium py-3 px-8 rounded-full transition-all transform hover:scale-105 shadow-lg"
          >
            浏览菜单
          </a>
          <a 
            href="/contact" 
            className="bg-transparent border-2 border-white hover:bg-white/10 text-white font-medium py-3 px-8 rounded-full transition-all"
          >
            联系我们
          </a>
        </div>
      </div>
      
      {/* 装饰性向下滚动指示器 */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10 animate-bounce">
        <i className="fa-solid fa-chevron-down text-white text-2xl"></i>
      </div>
    </section>
  );
}