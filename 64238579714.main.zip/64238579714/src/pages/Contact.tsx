import ContactInfo from '@/components/ContactInfo';

export default function Contact() {
  return (
    <div>
      {/* 联系页面头部 */}
      <section className="relative h-64 bg-gray-800 flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Restaurant%20interior%20warm%20lighting%20cozy%20ambience&sign=a4761df34455b497179c2f8f4f4ed631" 
            alt="餐厅环境" 
            className="w-full h-full object-cover opacity-40"
          />
        </div>
        <div className="relative z-10 text-center text-white px-4">
          <h1 className="text-4xl font-bold mb-2">联系我们</h1>
          <p className="text-xl opacity-90">欢迎前来就餐或通过以下方式与我们联系</p>
        </div>
      </section>
      
      <ContactInfo />
    </div>
  );
}