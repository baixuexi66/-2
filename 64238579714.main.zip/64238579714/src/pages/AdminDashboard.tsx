import { useContext, useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '@/contexts/authContext';
import { thaiDishes, burmeseDishes, taiwaneseDishes, getMenuData } from '@/lib/menuData';
import { toast } from 'sonner';

// 定义管理面板的标签页类型
type Tab = 'menu' | 'contact' | 'orders';

import { MenuItem } from '@/lib/menuData';

export default function AdminDashboard() {
  const { isAuthenticated, user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>('menu');
  const [menuItems, setMenuItems] = useState({
    thai: thaiDishes,
    burmese: burmeseDishes,
    taiwanese: taiwaneseDishes
  });
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [currentEditingItem, setCurrentEditingItem] = useState<MenuItem | null>(null);
  const [currentEditingCategory, setCurrentEditingCategory] = useState<string | null>(null);
  const [newDish, setNewDish] = useState({
    name: '',
    description: '',
    price: '',
    image: '',
    isSoldOut: false,
    category: 'thai' as 'thai' | 'burmese' | 'taiwanese'
  });
  
  // 从本地存储加载菜单数据
  useEffect(() => {
  const { thai, burmese, taiwanese } = getMenuData();
  setMenuItems({ thai, burmese, taiwanese });
  }, []);

  // 检查用户是否已认证，如果未认证则重定向到登录页
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  // 保存菜单数据到本地存储
  const saveMenuToLocalStorage = () => {
    localStorage.setItem('restaurantMenu', JSON.stringify(menuItems));
    toast.success('菜单数据已保存');
  };

  // 处理退出登录
  const handleLogout = () => {
    logout();
    toast.info('已退出登录');
    navigate('/');
  };

  // 处理菜单项删除
  const handleDeleteItem = (id: number, category: 'thai' | 'burmese' | 'taiwanese') => {
    if (window.confirm('确定要删除这个菜品吗？')) {
      const updatedItems = menuItems[category].filter(item => item.id !== id);
      setMenuItems({
        ...menuItems,
        [category]: updatedItems
      });
      toast.success('菜品已删除');
      saveMenuToLocalStorage();
    }
  };

  // 打开编辑模态框
  const openEditModal = (item: MenuItem, category: string) => {
    setCurrentEditingItem({...item});
    setCurrentEditingCategory(category);
    setIsEditModalOpen(true);
  };

  // 处理编辑输入变化
  const handleEditInputChange = (field: keyof MenuItem, value: string | boolean) => {
    if (currentEditingItem) {
      setCurrentEditingItem(prev => prev ? {...prev, [field]: value} : null);
    }
  };

  // 保存编辑
  const handleSaveEdit = () => {
    if (!currentEditingItem || !currentEditingCategory) return;
    
    // 更新菜单数据
    const updatedCategoryItems = menuItems[currentEditingCategory as keyof typeof menuItems].map(item => 
      item.id === currentEditingItem.id ? currentEditingItem : item
    );
    
    const updatedMenuItems = {
      ...menuItems,
      [currentEditingCategory]: updatedCategoryItems
    };
    
    try {
      // 先保存到本地存储，再更新状态
      localStorage.setItem('restaurantMenu', JSON.stringify(updatedMenuItems));
      setMenuItems(updatedMenuItems);
      setIsEditModalOpen(false);
      toast.success('菜品更新成功');
    } catch (error) {
      console.error('保存菜品失败:', error);
      toast.error('保存失败，请重试');
    }
  }

  // 处理添加菜品
  const handleAddDish = () => {
    setIsAddModalOpen(true);
    // 重置新菜品表单
    setNewDish({
      name: '',
      description: '',
      price: '',
      image: '',
      isSoldOut: false,
      category: 'thai'
    });
  };

  // 处理新菜品输入变化
  const handleNewDishInputChange = (field: keyof typeof newDish, value: string | boolean | 'thai' | 'burmese' | 'taiwanese') => {
    setNewDish(prev => ({
      ...prev,
      [field]: value
    }));
  };

  // 保存新菜品
  const saveNewDish = () => {
    if (!newDish.name || !newDish.description || !newDish.price) {
      toast.error('请填写所有必填字段');
      return;
    }

    // 生成新ID - 取当前分类中最大ID + 1
    const categoryItems = menuItems[newDish.category];
    const maxId = categoryItems.reduce((max, item) => Math.max(max, item.id), 0);
    const newId = maxId + 1;

    // 创建新菜品对象
    const dishToAdd: MenuItem = {
      id: newId,
      name: newDish.name,
      description: newDish.description,
      price: newDish.price,
      image: newDish.image || `https://space.coze.cn/api/coze_space/gen_image?image_size=square&prompt=Southeast%20Asian%20food%20dish%20${newDish.name}`,
      isSoldOut: newDish.isSoldOut
    };

    // 更新菜单数据
    const updatedMenuItems = {
      ...menuItems,
      [newDish.category]: [...categoryItems, dishToAdd]
    };

    try {
      localStorage.setItem('restaurantMenu', JSON.stringify(updatedMenuItems));
      setMenuItems(updatedMenuItems);
      setIsAddModalOpen(false);
      toast.success('新菜品添加成功');
    } catch (error) {
      console.error('保存新菜品失败:', error);
      toast.error('保存失败，请重试');
    }
  };

  // 如果用户未认证，不渲染管理面板内容
  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部导航栏 */}
      <nav className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <h1 className="text-xl font-bold text-amber-600 flex items-center">
                <i className="fa-solid fa-tachometer-alt mr-2"></i>
                餐厅管理后台
              </h1>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-gray-700 mr-4">
                欢迎, {user?.username}
              </span>
              <button
                onClick={handleLogout}
                className="text-gray-700 hover:text-amber-600 transition-colors"
              >
                <i className="fa-solid fa-sign-out-alt mr-1"></i>
                退出登录
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* 主内容区 */}
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {/* 标签页导航 */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('menu')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'menu'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fa-solid fa-utensils mr-2"></i>菜单管理
            </button>
            <button
              onClick={() => setActiveTab('contact')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'contact'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fa-solid fa-address-card mr-2"></i>联系信息
            </button>
            <button
              onClick={() => setActiveTab('orders')}
              className={`py-4 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'orders'
                  ? 'border-amber-500 text-amber-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <i className="fa-solid fa-receipt mr-2"></i>订单管理
            </button>
          </nav>
        </div>

        {/* 标签页内容 */}
        <div>
          {activeTab === 'menu' && (
            <div className="bg-white shadow rounded-lg p-6">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold text-gray-800">菜单管理</h2>
               <button 
                 onClick={handleAddDish}
                 className="bg-amber-600 hover:bg-amber-700 text-white py-2 px-4 rounded-md transition-colors"
               >
                 <i className="fa-solid fa-plus mr-1"></i>添加菜品
               </button>
              </div>

              {/* 泰国料理 */}
              <div className="mb-10">
                <h3 className="text-xl font-semibold text-gray-700 mb-4 flex items-center">
                  <span className="bg-green-100 text-green-800 p-1 rounded mr-2">
                    <i className="fa-solid fa-leaf"></i>
                  </span>
                  泰国料理
                </h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">菜品名称</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">描述</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">价格</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {menuItems.thai.map((item) => (
                        <tr key={item.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <img className="h-10 w-10 rounded-md object-cover" src={item.image} alt={item.name} />
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{item.name}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-500 line-clamp-2 max-w-xs">{item.description}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{item.price}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                             <button 
                               onClick={() => openEditModal(item, 'thai')}
                               className="text-blue-600 hover:text-blue-900 mr-4"
                             >
                               <i className="fa-solid fa-edit mr-1"></i>编辑
                             </button>
                            <button 
                              onClick={() => handleDeleteItem(item.id, 'thai')}
                              className="text-red-600 hover:text-red-900"
                            >
                              <i className="fa-solid fa-trash mr-1"></i>删除
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 缅甸料理 */}
              <div className="mb-10">
                <h3 className="text-xl font-semibold text-gray-700 mb-4 flex items-center">
                  <span className="bg-amber-100 text-amber-800 p-1 rounded mr-2">
                    <i className="fa-solid fa-pepper-hot"></i>
                  </span>
                  缅甸料理
                </h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">菜品名称</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">描述</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">价格</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {menuItems.burmese.map((item) => (
                        <tr key={item.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <img className="h-10 w-10 rounded-md object-cover" src={item.image} alt={item.name} />
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{item.name}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-500 line-clamp-2 max-w-xs">{item.description}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{item.price}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                             <button 
                               onClick={() => openEditModal(item, 'burmese')}
                               className="text-blue-600 hover:text-blue-900 mr-4"
                             >
                               <i className="fa-solid fa-edit mr-1"></i>编辑
                             </button>
                            <button 
                              onClick={() => handleDeleteItem(item.id, 'burmese')}
                              className="text-red-600 hover:text-red-900"
                            >
                              <i className="fa-solid fa-trash mr-1"></i>删除
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 台湾料理 */}
              <div>
                <h3 className="text-xl font-semibold text-gray-700 mb-4 flex items-center">
                  <span className="bg-red-100 text-red-800 p-1 rounded mr-2">
                    <i className="fa-solid fa-utensils"></i>
                  </span>
                  台湾料理
                </h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">菜品名称</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">描述</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">价格</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">操作</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {menuItems.taiwanese.map((item) => (
                        <tr key={item.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <img className="h-10 w-10 rounded-md object-cover" src={item.image} alt={item.name} />
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{item.name}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-500 line-clamp-2 max-w-xs">{item.description}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{item.price}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                             <button 
                               onClick={() => openEditModal(item, 'taiwanese')}
                               className="text-blue-600 hover:text-blue-900 mr-4"
                             >
                               <i className="fa-solid fa-edit mr-1"></i>编辑
                             </button>
                            <button 
                              onClick={() => handleDeleteItem(item.id, 'taiwanese')}
                              className="text-red-600 hover:text-red-900"
                            >
                              <i className="fa-solid fa-trash mr-1"></i>删除
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
               </div>
               
               {/* 编辑菜品模态框 */}
               {isEditModalOpen && currentEditingItem && (
                 <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                   <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
                     <div className="p-6 border-b border-gray-200">
                       <h3 className="text-xl font-bold text-gray-800">编辑菜品</h3>
                     </div>
                     <div className="p-6 space-y-4">
                       <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1">菜品名称</label>
                         <input
                           type="text"
                           value={currentEditingItem.name}
                           onChange={(e) => handleEditInputChange('name', e.target.value)}
                           className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                         />
                       </div>
                       <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1">描述</label>
                         <textarea
                           value={currentEditingItem.description}
                           onChange={(e) => handleEditInputChange('description', e.target.value)} 
                           className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent min-h-[80px]"
                           rows={3}
                         ></textarea>
                       </div>
                       <div>
                         <label className="block text-sm font-medium text-gray-700 mb-1">价格</label>
                         <input
                           type="text"
                           value={currentEditingItem.price}
                           onChange={(e) => handleEditInputChange('price', e.target.value)}
                           className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                         />
                       </div>
                       <div className="flex items-center">
                         <input
                           id="isSoldOut"
                           type="checkbox"
                           checked={currentEditingItem.isSoldOut}
                           onChange={(e) => handleEditInputChange('isSoldOut', e.target.checked)}
                           className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                         />
                         <label htmlFor="isSoldOut" className="ml-2 block text-sm text-gray-700">标记为售罄</label>
                       </div>
                     </div>
                     <div className="p-6 flex justify-end space-x-3 border-t border-gray-200">
                       <button
                         onClick={() => setIsEditModalOpen(false)}
                         className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors"
                       >
                         取消
                       </button>
                       <button
                         onClick={handleSaveEdit}
                         className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors"
                       >
                         保存
                       </button>
                     </div>
                   </div>
                 </div>
                )}

                {/* 添加菜品模态框 */}
                {isAddModalOpen && (
                  <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
                      <div className="p-6 border-b border-gray-200">
                        <h3 className="text-xl font-bold text-gray-800">添加新菜品</h3>
                      </div>
                      <div className="p-6 space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">菜品分类</label>
                          <select
                            value={newDish.category}
                            onChange={(e) => handleNewDishInputChange('category', e.target.value as 'thai' | 'burmese' | 'taiwanese')}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                          >
                            <option value="thai">泰国料理</option>
                            <option value="burmese">缅甸料理</option>
                            <option value="taiwanese">台湾料理</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">菜品名称*</label>
                          <input
                            type="text"
                            value={newDish.name}
                            onChange={(e) => handleNewDishInputChange('name', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                            placeholder="输入菜品名称"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">描述*</label>
                          <textarea
                            value={newDish.description}
                            onChange={(e) => handleNewDishInputChange('description', e.target.value)} 
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent min-h-[80px]"
                            placeholder="输入菜品描述"
                            rows={3}
                          ></textarea>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">价格*</label>
                          <input
                            type="text"
                            value={newDish.price}
                            onChange={(e) => handleNewDishInputChange('price', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                            placeholder="输入价格，例如 ¥88"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">图片URL (可选)</label>
                          <input
                            type="text"
                            value={newDish.image}
                            onChange={(e) => handleNewDishInputChange('image', e.target.value)}
                            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                            placeholder="输入图片URL地址"
                          />
                        </div>
                        <div className="flex items-center">
                          <input
                            id="newIsSoldOut"
                            type="checkbox"
                            checked={newDish.isSoldOut}
                            onChange={(e) => handleNewDishInputChange('isSoldOut', e.target.checked)}
                            className="h-4 w-4 text-amber-600 focus:ring-amber-500 border-gray-300 rounded"
                          />
                          <label htmlFor="newIsSoldOut" className="ml-2 block text-sm text-gray-700">标记为售罄</label>
                        </div>
                      </div>
                      <div className="p-6 flex justify-end space-x-3 border-t border-gray-200">
                        <button
                          onClick={() => setIsAddModalOpen(false)}
                          className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors"
                        >
                          取消
                        </button>
                        <button
                          onClick={saveNewDish}
                          className="bg-amber-600 hover:bg-amber-700 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 transition-colors"
                        >
                          添加
                        </button>
                      </div>
                    </div>
                  </div>
                )}
               </div>
            </div>
          )}

          {activeTab === 'contact' && (
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">联系信息管理</h2>
              <div className="space-y-6">
                <div className="text-center py-12">
                  <i className="fa-solid fa-info-circle text-5xl text-gray-300 mb-4"></i>
                  <h3 className="text-lg font-medium text-gray-900 mb-1">联系信息管理功能</h3>
                  <p className="text-gray-500">此功能即将上线，敬请期待</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="bg-white shadow rounded-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">订单管理</h2>
              <div className="text-center py-12">
                <i className="fa-solid fa-info-circle text-5xl text-gray-300 mb-4"></i>
                <h3 className="text-lg font-medium text-gray-900 mb-1">订单管理功能</h3>
                <p className="text-gray-500">此功能即将上线，敬请期待</p>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}