import { createContext, useState, useEffect, ReactNode } from "react";

interface AuthContextType {
  isAuthenticated: boolean;
  user: { username: string; role: string } | null;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

export const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  user: null,
  login: () => false,
  logout: () => {},
});

export const useAuthProvider = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<{ username: string; role: string } | null>(null);
  
  // 检查本地存储中的登录状态
  useEffect(() => {
    const savedUser = localStorage.getItem('adminUser');
    if (savedUser) {
      try {
        const parsedUser = JSON.parse(savedUser);
        setIsAuthenticated(true);
        setUser(parsedUser);
      } catch (error) {
        console.error('Failed to parse saved user', error);
        localStorage.removeItem('adminUser');
      }
    }
  }, []);
  
  // 登录功能 - 使用硬编码的管理员凭据作为示例
  const login = (username: string, password: string): boolean => {
    const validAdmin = username === 'admin' && password === 'admin123';
    
    if (validAdmin) {
      const adminUser = { username, role: 'admin' };
      setIsAuthenticated(true);
      setUser(adminUser);
      localStorage.setItem('adminUser', JSON.stringify(adminUser));
      return true;
    }
    
    return false;
  };
  
  // 登出功能
  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('adminUser');
  };
  
  return {
    isAuthenticated,
    user,
    login,
    logout
  };
};